<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Button extends CI_Controller {
	public function index()
	{
		$this->load->view('header');
		$this->load->view('button');
		$this->load->view('footer');
	}
}
