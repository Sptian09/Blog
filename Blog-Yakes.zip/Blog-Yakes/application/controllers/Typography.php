<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Typography extends CI_Controller {
	public function index()
	{
		$this->load->view('header');
		$this->load->view('typography');
		$this->load->view('footer');
	}
}
