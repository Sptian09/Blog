<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Element extends CI_Controller {
	public function index()
	{
		$this->load->view('header');
		$this->load->view('element');
		$this->load->view('footer');
	}
}
